#!/usr/bin/env python3
"""Deterministic reward for database-backed tool trajectories."""

from __future__ import annotations

import json
import math
import os
import re
from dataclasses import asdict, dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any, Iterable


NETWORK_PATTERN = re.compile(
    r"(?:^|[;&|\s])(curl|wget|ssh|scp|nc|ncat|telnet|ftp|git\s+clone|pip\s+install|apt(?:-get)?)\b",
    re.IGNORECASE,
)
DESTRUCTIVE_PATTERN = re.compile(
    r"(?:\brm\s+-[^\n]*r[^\n]*\s+/(?:\s|$)|\bmkfs\b|\bdd\s+if=|"
    r"\b(?:shutdown|reboot|docker|podman|mount|umount|kill|killall|pkill)\b)",
    re.IGNORECASE,
)
ERROR_PATTERN = re.compile(r"(?:^|\n)\s*(?:error|traceback|permission denied|command not found)\b", re.IGNORECASE)
ARTIFACT_PATTERN = re.compile(r"/workspace/([^\s`'\"<>]+)")
ALLOWED_ARTIFACT_SUFFIXES = {".md", ".txt", ".json", ".csv"}


@dataclass(frozen=True)
class RewardBreakdown:
    score: float
    safe: bool
    valid_tool_protocol: bool
    successful_tool_use: bool
    queried_required_tables: bool
    has_final_answer: bool
    gold_evidence: bool


def parse_tool_call(message: dict[str, Any]) -> tuple[str, dict[str, Any]] | None:
    if message.get("role") != "tool_call":
        return None
    content = message.get("content")
    if not isinstance(content, str):
        return None
    try:
        payload = json.loads(content)
    except json.JSONDecodeError:
        return None
    if not isinstance(payload, dict) or not isinstance(payload.get("name"), str):
        return None
    arguments = payload.get("arguments")
    if not isinstance(arguments, dict):
        return None
    return payload["name"], arguments


def bash_commands(messages: Iterable[dict[str, Any]]) -> tuple[list[str], bool]:
    commands: list[str] = []
    valid = True
    for message in messages:
        if message.get("role") != "tool_call":
            continue
        parsed = parse_tool_call(message)
        if parsed is None:
            valid = False
            continue
        name, arguments = parsed
        if name != "bash":
            continue
        command = arguments.get("command")
        if not isinstance(command, str) or not command.strip():
            valid = False
            continue
        commands.append(command)
    return commands, valid


def is_safe_command(command: str) -> bool:
    return not NETWORK_PATTERN.search(command) and not DESTRUCTIVE_PATTERN.search(command)


def has_successful_tool_response(messages: Iterable[dict[str, Any]]) -> bool:
    for message in messages:
        if message.get("role") != "tool_response":
            continue
        content = message.get("content")
        if isinstance(content, str) and content.strip() and not ERROR_PATTERN.search(content):
            return True
    return False


def queried_tables(commands: Iterable[str], required_tables: Iterable[str]) -> bool:
    combined = "\n".join(commands)
    return all(re.search(rf"\b{re.escape(table)}\b", combined, re.IGNORECASE) for table in required_tables)


def last_assistant_content(messages: Iterable[dict[str, Any]]) -> str:
    values = [
        message.get("content")
        for message in messages
        if message.get("role") == "assistant" and isinstance(message.get("content"), str)
    ]
    return values[-1].strip() if values else ""


def normalize_number_text(value: int | float) -> set[str]:
    variants = {str(value), f"{value:,}"}
    if isinstance(value, float) and value.is_integer():
        integer = int(value)
        variants.update({str(integer), f"{integer:,}"})
    return variants


def gold_matches_text(gold: Any, text: str) -> bool:
    if gold is None or not text:
        return False
    if isinstance(gold, bool):
        return str(gold).casefold() in text.casefold()
    if isinstance(gold, (int, float)):
        numeric_tokens = re.findall(r"(?<![\d.])[-+]?\d[\d,]*(?:\.\d+)?(?![\d.])", text)
        return any(
            math.isclose(float(token.replace(",", "")), float(gold), rel_tol=1e-6, abs_tol=1e-6)
            for token in numeric_tokens
        )
    if isinstance(gold, str):
        return gold.strip().casefold() in text.casefold()
    serialized = json.dumps(gold, ensure_ascii=False, sort_keys=True)
    return serialized.casefold() in text.casefold()


def artifact_texts(final_answer: str, workspace: Path | None, supplied: Iterable[str] | None) -> list[str]:
    texts = [value for value in supplied or [] if isinstance(value, str)]
    if workspace is None:
        return texts
    root = workspace.resolve()
    for relative in ARTIFACT_PATTERN.findall(final_answer):
        candidate = (root / relative.rstrip(".,;:，。；：）)]}")).resolve()
        try:
            candidate.relative_to(root)
        except ValueError:
            continue
        if candidate.suffix.casefold() not in ALLOWED_ARTIFACT_SUFFIXES or not candidate.is_file():
            continue
        texts.append(candidate.read_text(encoding="utf-8", errors="replace")[:1_000_000])
    return texts


def score_trajectory(
    messages: list[dict[str, Any]],
    verifier: dict[str, Any],
    *,
    workspace: Path | None = None,
    supplied_artifact_texts: Iterable[str] | None = None,
) -> RewardBreakdown:
    commands, valid_protocol = bash_commands(messages)
    safe = bool(commands) and all(is_safe_command(command) for command in commands)
    successful = has_successful_tool_response(messages)
    required = [str(value) for value in verifier.get("required_tables") or []]
    queried = bool(required) and queried_tables(commands, required)
    final_answer = last_assistant_content(messages)
    has_final = bool(final_answer)
    evidence_text = "\n".join(
        [final_answer, *artifact_texts(final_answer, workspace, supplied_artifact_texts)]
    )
    gold_value = (verifier.get("gold") or {}).get("value")
    gold_evidence = gold_matches_text(gold_value, evidence_text)

    if not safe or not valid_protocol:
        score = 0.0
    else:
        score = 0.0
        score += 0.10
        score += 0.10 if successful else 0.0
        score += 0.20 if queried else 0.0
        score += 0.10 if has_final else 0.0
        if successful and queried and has_final and gold_evidence:
            score += 0.50
    return RewardBreakdown(
        score=round(score, 6),
        safe=safe,
        valid_tool_protocol=valid_protocol,
        successful_tool_use=successful,
        queried_required_tables=queried,
        has_final_answer=has_final,
        gold_evidence=gold_evidence,
    )


@lru_cache(maxsize=4)
def load_manifest(path: str) -> dict[str, dict[str, Any]]:
    values: dict[str, dict[str, Any]] = {}
    with Path(path).open(encoding="utf-8") as handle:
        for raw_line in handle:
            if not raw_line.strip():
                continue
            row = json.loads(raw_line)
            values[str(row["verifier_id"])] = row
            values[str(row["task_id"])] = row
    return values


async def reward_func(args: Any, sample: Any, **_: Any) -> float:
    """slime ``--custom-rm-path`` adapter.

    The custom generate loop must preserve parsed messages on
    ``sample.trajectory_messages``. Gold labels remain in a separate private
    manifest and are never rendered into the model prompt.
    """

    manifest_path = os.environ.get("SLIME_TRAJECTORY_VERIFIER_MANIFEST")
    if not manifest_path:
        raise RuntimeError("SLIME_TRAJECTORY_VERIFIER_MANIFEST is not set")
    metadata = getattr(sample, "metadata", {}) or {}
    environment = metadata.get("environment") or {}
    verifier_id = metadata.get("verifier_id") or f"{environment.get('environment_id')}:{environment.get('task_id')}"
    verifier = load_manifest(manifest_path).get(str(verifier_id))
    if verifier is None:
        verifier = load_manifest(manifest_path).get(str(environment.get("task_id")))
    if verifier is None:
        raise KeyError(f"no verifier spec for {verifier_id!r}")
    messages = getattr(sample, "trajectory_messages", None)
    if not isinstance(messages, list):
        raise TypeError("custom generate must set sample.trajectory_messages")
    supplied = getattr(sample, "trajectory_artifact_texts", None)
    breakdown = score_trajectory(messages, verifier, supplied_artifact_texts=supplied)
    metadata["reward_breakdown"] = asdict(breakdown)
    sample.metadata = metadata
    return breakdown.score
