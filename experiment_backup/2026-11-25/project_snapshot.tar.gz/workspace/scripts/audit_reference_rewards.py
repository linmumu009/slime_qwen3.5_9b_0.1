#!/usr/bin/env python3
"""Score completed reference trajectories with the deterministic verifier."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from dataclasses import asdict
from pathlib import Path
from typing import Any, Iterable

from scripts.trajectory_reward import score_trajectory


def iter_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open(encoding="utf-8") as handle:
        for raw_line in handle:
            if raw_line.strip():
                yield json.loads(raw_line)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("trajectories", type=Path)
    parser.add_argument("environment_manifest", type=Path)
    parser.add_argument("verifier_manifest", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--sandbox-root", type=Path)
    parser.add_argument("--dataset-group", default="train_strong_verified")
    args = parser.parse_args()

    trajectories = list(iter_jsonl(args.trajectories.resolve()))
    environments = {
        int(row["combined_line"]): row
        for row in iter_jsonl(args.environment_manifest.resolve())
        if row.get("dataset_group") == args.dataset_group
    }
    verifiers = {
        int(row["combined_line"]): row for row in iter_jsonl(args.verifier_manifest.resolve())
    }

    results: list[dict[str, Any]] = []
    for combined_line, environment in sorted(environments.items()):
        verifier = verifiers.get(combined_line)
        if verifier is None:
            results.append(
                {
                    "combined_line": combined_line,
                    "task_id": environment.get("task_id"),
                    "status": "no_verifier",
                }
            )
            continue
        if combined_line > len(trajectories):
            raise ValueError(f"trajectory data has no combined line {combined_line}")
        trajectory = trajectories[combined_line - 1]
        workspace = (
            args.sandbox_root.resolve() / environment["environment_id"]
            if args.sandbox_root
            else None
        )
        breakdown = score_trajectory(
            trajectory.get("messages") or [], verifier, workspace=workspace
        )
        results.append(
            {
                "combined_line": combined_line,
                "task_id": environment.get("task_id"),
                "status": "scored",
                **asdict(breakdown),
            }
        )

    scored = [row for row in results if row["status"] == "scored"]
    score_counts = Counter(str(row["score"]) for row in scored)
    summary = {
        "reference_records": len(trajectories),
        "environment_records": len(environments),
        "verifier_records": len(verifiers),
        "scored_records": len(scored),
        "unscored_records": len(results) - len(scored),
        "full_reward_records": sum(row["score"] == 1.0 for row in scored),
        "safe_records": sum(row["safe"] for row in scored),
        "required_table_records": sum(row["queried_required_tables"] for row in scored),
        "gold_evidence_records": sum(row["gold_evidence"] for row in scored),
        "score_distribution": dict(sorted(score_counts.items())),
    }
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps({"summary": summary, "records": results}, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
