#!/usr/bin/env python3
"""Build a private verifier manifest from task definitions and pristine sandboxes."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shlex
import sqlite3
from pathlib import Path
from typing import Any, Iterable


READ_ONLY_SQL_PREFIXES = ("select", "with", "pragma")
TABLE_PATTERN = re.compile(r"\b(?:from|join)\s+[`\"\[]?([A-Za-z_][\w.]*)", re.IGNORECASE)


class TaskDefinitionNotFound(LookupError):
    pass


def iter_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open(encoding="utf-8") as handle:
        for line_number, raw_line in enumerate(handle, start=1):
            if not raw_line.strip():
                continue
            value = json.loads(raw_line)
            if not isinstance(value, dict):
                raise ValueError(f"{path}:{line_number}: expected a JSON object")
            yield value


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def validate_read_only_sql(sql: str) -> str:
    normalized = sql.strip().rstrip(";").strip()
    if not normalized:
        raise ValueError("verification_sql is empty")
    if ";" in normalized:
        raise ValueError("verification_sql must contain exactly one statement")
    if not normalized.casefold().startswith(READ_ONLY_SQL_PREFIXES):
        raise ValueError("verification_sql must be SELECT, WITH, or PRAGMA")
    return normalized


def normalize_result(rows: list[tuple[Any, ...]]) -> Any:
    if len(rows) == 1 and len(rows[0]) == 1:
        return rows[0][0]
    return [list(row) for row in rows]


def execute_read_only(database: Path, sql: str) -> Any:
    uri = f"file:{database.resolve().as_posix()}?mode=ro"
    with sqlite3.connect(uri, uri=True) as connection:
        connection.execute("PRAGMA query_only = ON")
        rows = connection.execute(validate_read_only_sql(sql)).fetchall()
    return normalize_result(rows)


def values_equal(observed: Any, declared: Any) -> bool:
    if isinstance(observed, (int, float)) and isinstance(declared, (int, float)):
        return float(observed) == float(declared)
    return observed == declared


def load_task(task_file: Path, task_id: str) -> dict[str, Any]:
    matches = [row for row in iter_jsonl(task_file) if row.get("task_id") == task_id]
    if len(matches) != 1:
        raise ValueError(f"expected one {task_id!r} in {task_file}, found {len(matches)}")
    return matches[0]


def task_signature(task: dict[str, Any]) -> str:
    gold = task.get("gold_answer") or {}
    criteria = task.get("verification_criteria") or {}
    signature = {
        "task_id": task.get("task_id"),
        "natural_language_instruction": task.get("natural_language_instruction"),
        "required_tables": criteria.get("must_query_tables") or [],
        "answer_type": gold.get("answer_type"),
        "verification_sql": validate_read_only_sql(str(gold.get("verification_sql") or "")),
    }
    return hashlib.sha256(
        json.dumps(signature, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def normalized_text(value: Any) -> str:
    return "".join(str(value or "").split()).casefold()


def task_prompts(task: dict[str, Any]) -> set[str]:
    prompts = {normalized_text(task.get("natural_language_instruction"))}
    for variant in task.get("instruction_variants") or []:
        if isinstance(variant, dict):
            prompts.add(normalized_text(variant.get("text")))
    return {value for value in prompts if value}


def recover_task_definition(
    sandbox_root: Path, task_type: str, task_id: str, user_prompt: str | None
) -> tuple[dict[str, Any], Path, int]:
    candidates: list[tuple[dict[str, Any], Path]] = []
    for task_file in sorted(sandbox_root.glob(f"*/*/{task_type}_tasks.jsonl")):
        for task in iter_jsonl(task_file):
            if task.get("task_id") != task_id:
                continue
            validation = task.get("validation") or {}
            gold = task.get("gold_answer") or {}
            if not validation.get("checked_against_database") or not gold.get("verification_sql"):
                continue
            candidates.append((task, task_file))
    if not candidates:
        raise TaskDefinitionNotFound(f"no recoverable definition for {task_id!r}")
    if user_prompt:
        prompt = normalized_text(user_prompt)
        prompt_matches = [(task, path) for task, path in candidates if prompt in task_prompts(task)]
        if not prompt_matches:
            raise TaskDefinitionNotFound(
                f"{task_id}: no verified task definition matches the trajectory prompt"
            )
        candidates = prompt_matches
    signatures = {task_signature(task) for task, _ in candidates}
    if len(signatures) != 1:
        raise ValueError(f"{task_id}: fallback task definitions disagree across environments")
    task, source = candidates[0]
    return task, source, len(candidates)


def parse_scalar(value: str) -> Any:
    text = value.strip()
    if not text or "\n" in text:
        raise ValueError("reference verification response must be a single scalar line")
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        try:
            return float(text)
        except ValueError:
            return text


def task_from_reference_trajectory(trajectory: dict[str, Any]) -> dict[str, Any]:
    messages = trajectory.get("messages") or []
    candidates: list[tuple[str, Any, list[str]]] = []
    for index, message in enumerate(messages):
        if not isinstance(message, dict) or message.get("role") != "tool_call":
            continue
        try:
            payload = json.loads(message.get("content") or "")
        except json.JSONDecodeError:
            continue
        if payload.get("name") != "bash" or not isinstance(payload.get("arguments"), dict):
            continue
        command = payload["arguments"].get("command")
        if not isinstance(command, str):
            continue
        try:
            argv = shlex.split(command)
        except ValueError:
            continue
        sqlite_indexes = [position for position, token in enumerate(argv) if token.endswith("sqlite3")]
        if not sqlite_indexes:
            continue
        sqlite_index = sqlite_indexes[-1]
        if len(argv) <= sqlite_index + 2:
            continue
        try:
            sql = validate_read_only_sql(argv[sqlite_index + 2])
        except ValueError:
            continue
        if index + 1 >= len(messages) or messages[index + 1].get("role") != "tool_response":
            continue
        response = messages[index + 1].get("content")
        if not isinstance(response, str):
            continue
        tables = sorted(set(TABLE_PATTERN.findall(sql)))
        if not tables:
            continue
        try:
            parsed_response = parse_scalar(response)
        except ValueError:
            continue
        candidates.append((sql, parsed_response, tables))
    if len(candidates) != 1:
        raise ValueError(
            f"reference fallback requires exactly one scalar read-only SQLite query, found {len(candidates)}"
        )
    sql, value, tables = candidates[0]
    return {
        "verification_criteria": {"must_query_tables": tables},
        "gold_answer": {
            "answer_type": "numeric" if isinstance(value, (int, float)) else "text",
            "value": value,
            "text": None,
            "verification_sql": sql,
        },
        "validation": {"checked_against_database": True},
    }


def build_spec(
    row: dict[str, Any],
    sandbox_root: Path,
    digest_cache: dict[Path, str],
    user_prompt: str | None = None,
    trajectory: dict[str, Any] | None = None,
) -> dict[str, Any]:
    environment_id = str(row["environment_id"])
    environment_dir = (sandbox_root / environment_id).resolve()
    database = environment_dir / "logistics.sqlite"
    task_type = str(row["task_type"])
    task_file = environment_dir / f"{task_type}_tasks.jsonl"
    if not environment_dir.is_dir():
        raise FileNotFoundError(f"missing environment: {environment_dir}")
    if not database.is_file():
        raise FileNotFoundError(f"missing database: {database}")
    recovered_definition = not task_file.is_file()
    definition_mode = "direct"
    if recovered_definition:
        try:
            task, definition_source, consensus_count = recover_task_definition(
                sandbox_root, task_type, str(row["task_id"]), user_prompt
            )
            definition_mode = "consensus_sql"
        except TaskDefinitionNotFound:
            if trajectory is None:
                raise
            task = task_from_reference_trajectory(trajectory)
            definition_source = f"reference_trajectory_line_{row['combined_line']}"
            consensus_count = 1
            definition_mode = "reference_sql"
    else:
        task = load_task(task_file, str(row["task_id"]))
        definition_source = task_file
        consensus_count = 1
    criteria = task.get("verification_criteria") or {}
    required_tables = criteria.get("must_query_tables") or []
    gold = task.get("gold_answer") or {}
    verification_sql = validate_read_only_sql(str(gold.get("verification_sql") or ""))
    observed = execute_read_only(database, verification_sql)
    declared = gold.get("value")
    declared_match = None if definition_mode == "consensus_sql" else values_equal(observed, declared)

    validation = task.get("validation") or {}
    if not validation.get("checked_against_database"):
        raise ValueError(f"{row['task_id']}: task is not database-validated")
    if not required_tables:
        raise ValueError(f"{row['task_id']}: must_query_tables is empty")
    if declared_match is False:
        raise ValueError(
            f"{row['task_id']}: declared gold {declared!r} does not match read-only result {observed!r}"
        )

    if database not in digest_cache:
        digest_cache[database] = sha256_file(database)
    return {
        "verifier_id": f"{environment_id}:{row['task_id']}",
        "combined_line": int(row["combined_line"]),
        "environment_id": environment_id,
        "task_id": str(row["task_id"]),
        "task_type": task_type,
        "required_tables": [str(value) for value in required_tables],
        "verification_sql": verification_sql,
        "gold": {
            "answer_type": gold.get("answer_type"),
            "value": observed if recovered_definition else declared,
            "text": None if recovered_definition else gold.get("text"),
        },
        "observed_result": observed,
        "declared_gold_matches_database": declared_match,
        "gold_source": {
            "direct": "declared_and_recomputed",
            "consensus_sql": "recomputed_from_consensus_sql",
            "reference_sql": "recomputed_from_reference_sql",
        }[definition_mode],
        "definition_source": (
            str(definition_source.relative_to(sandbox_root))
            if isinstance(definition_source, Path)
            else definition_source
        ),
        "definition_consensus_count": consensus_count,
        "database_sha256": digest_cache[database],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("environment_manifest", type=Path)
    parser.add_argument("sandbox_root", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--dataset-group", default="train_strong_verified")
    parser.add_argument(
        "--trajectory-data",
        type=Path,
        help="Completed trajectories in combined-line order; used only to disambiguate missing task definitions",
    )
    parser.add_argument(
        "--allow-rejects",
        action="store_true",
        help="Write unsupported rows to a rejection report instead of failing immediately",
    )
    args = parser.parse_args()

    rows = [
        row
        for row in iter_jsonl(args.environment_manifest.resolve())
        if row.get("dataset_group") == args.dataset_group
    ]
    if not rows:
        raise RuntimeError(f"no records found for dataset_group={args.dataset_group!r}")

    prompts_by_line: dict[int, str] = {}
    trajectories_by_line: dict[int, dict[str, Any]] = {}
    if args.trajectory_data:
        for line_number, trajectory in enumerate(iter_jsonl(args.trajectory_data.resolve()), start=1):
            trajectories_by_line[line_number] = trajectory
            messages = trajectory.get("messages") or []
            user_messages = [
                message.get("content")
                for message in messages
                if isinstance(message, dict)
                and message.get("role") == "user"
                and isinstance(message.get("content"), str)
            ]
            if user_messages:
                prompts_by_line[line_number] = user_messages[0]

    digest_cache: dict[Path, str] = {}
    specs: list[dict[str, Any]] = []
    rejected: list[dict[str, Any]] = []
    for row in rows:
        try:
            specs.append(
                build_spec(
                    row,
                    args.sandbox_root.resolve(),
                    digest_cache,
                    prompts_by_line.get(int(row["combined_line"])),
                    trajectories_by_line.get(int(row["combined_line"])),
                )
            )
        except (FileNotFoundError, LookupError, ValueError, sqlite3.DatabaseError) as error:
            if not args.allow_rejects:
                raise
            rejected.append(
                {
                    "combined_line": int(row["combined_line"]),
                    "environment_id": row.get("environment_id"),
                    "task_id": row.get("task_id"),
                    "reason": str(error),
                }
            )
    if not specs:
        raise RuntimeError("no verifier specs were built")
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8", newline="\n") as handle:
        for spec in specs:
            handle.write(json.dumps(spec, ensure_ascii=False, separators=(",", ":")) + "\n")
    rejected_path = output.with_suffix(".rejected.json")
    rejected_path.write_text(
        json.dumps(rejected, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )

    summary = {
        "records": len(specs),
        "distinct_environments": len({spec["environment_id"] for spec in specs}),
        "distinct_tasks": len({spec["task_id"] for spec in specs}),
        "declared_gold_matches": sum(
            spec["declared_gold_matches_database"] is True for spec in specs
        ),
        "recomputed_from_consensus_sql": sum(
            spec["gold_source"] == "recomputed_from_consensus_sql" for spec in specs
        ),
        "recomputed_from_reference_sql": sum(
            spec["gold_source"] == "recomputed_from_reference_sql" for spec in specs
        ),
        "all_verification_results_available": all(
            spec["observed_result"] is not None for spec in specs
        ),
        "rejected_records": len(rejected),
        "rejected_path": str(rejected_path),
        "output": str(output),
        "output_sha256": sha256_file(output),
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
