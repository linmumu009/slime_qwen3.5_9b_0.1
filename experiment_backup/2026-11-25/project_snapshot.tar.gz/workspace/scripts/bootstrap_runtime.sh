#!/usr/bin/env bash
set -euo pipefail

: "${WORKSPACE_ROOT:?Set WORKSPACE_ROOT to the mounted experiment workspace}"

SLIME_SOURCE="${SLIME_SOURCE:-${WORKSPACE_ROOT}/slime_fb42ae4}"
SGLANG_SOURCE="${SGLANG_SOURCE:-${WORKSPACE_ROOT}/sglang_5a15cde/python}"
TORCH29_RUNTIME_OVERLAY="${TORCH29_RUNTIME_OVERLAY:-${WORKSPACE_ROOT}/cann9_torch29_runtime}"

declare -A EXPECTED_SHA256=(
  ["${WORKSPACE_ROOT}/ray-2.56.0-cp311-cp311-manylinux2014_aarch64.whl"]="aea655831d25084cb343002a8e67a77b6aa552ddb776a65461d49f62884f096a"
  ["${WORKSPACE_ROOT}/cann9_assets/sglang_router-0.3.2-cp38-abi3-manylinux_2_17_aarch64.manylinux2014_aarch64.whl"]="40a10f3817b80377c2ceb326b625f24bd06eb97426e5044de722295ec7fa79c0"
  ["${WORKSPACE_ROOT}/wheelhouse/wandb-0.28.1-py3-none-manylinux_2_28_aarch64.whl"]="ae9ae6fb29e2e2b1d097ed8b75c0c0240c778c2a8cad1d996dee870a1e401c2c"
  ["${WORKSPACE_ROOT}/cann9_assets/sgl_kernel_npu-2026.6.1-cp311-cp311-linux_aarch64.whl"]="b0d85a733b824a118748b08b460f90fb420a4b8933f62c41fa7efa6a26a192b5"
  ["${WORKSPACE_ROOT}/cann9_assets/attentions-0.2-cp311-cp311-linux_aarch64.whl"]="c4197ae2f06ad00abdc3f966cbca1adf7e7651e65d2d8ab505336d879ee62dad"
)

for path in "${!EXPECTED_SHA256[@]}"; do
  if [[ ! -f "${path}" ]]; then
    echo "Missing offline wheel: ${path}" >&2
    exit 1
  fi
  actual=$(sha256sum "${path}" | awk '{print $1}')
  if [[ "${actual}" != "${EXPECTED_SHA256[${path}]}" ]]; then
    echo "SHA-256 mismatch for ${path}: ${actual}" >&2
    exit 1
  fi
done

for source in "${SLIME_SOURCE}" "${SGLANG_SOURCE}"; do
  if [[ ! -d "${source}" ]]; then
    echo "Missing source directory: ${source}" >&2
    exit 1
  fi
done

if [[ ! -d "${TORCH29_RUNTIME_OVERLAY}/sgl_kernel_npu" || ! -d "${TORCH29_RUNTIME_OVERLAY}/attentions" ]]; then
  echo "Missing Torch 2.9 runtime overlay: ${TORCH29_RUNTIME_OVERLAY}" >&2
  exit 1
fi
overlay_digest=$(
  cd "${TORCH29_RUNTIME_OVERLAY}"
  find sgl_kernel_npu attentions -type f ! -path '*/__pycache__/*' ! -name '*.pyc' -print0 \
    | LC_ALL=C sort -z | xargs -0 sha256sum | sha256sum | awk '{print $1}'
)
if [[ "${overlay_digest}" != "e354753f944178f6f01918c5ec71e0c6b747cef16ab6a440f3397e1a1913c569" ]]; then
  echo "SHA-256 mismatch for Torch 2.9 runtime overlay: ${overlay_digest}" >&2
  exit 1
fi
kernel_so_sha=$(sha256sum "${TORCH29_RUNTIME_OVERLAY}/sgl_kernel_npu/lib/libsgl_kernel_npu.so" | awk '{print $1}')
if [[ "${kernel_so_sha}" != "99683036021f3afced7e0b4119bafcdef2e6c65cbd2acf70e36efc7e4dc4405d" ]]; then
  echo "SHA-256 mismatch for working Torch 2.9 NPU kernel: ${kernel_so_sha}" >&2
  exit 1
fi

export PIP_NO_INDEX=1
export PIP_DISABLE_PIP_VERSION_CHECK=1
export WANDB_MODE=offline

python3 -m pip install --no-deps \
  "${WORKSPACE_ROOT}/ray-2.56.0-cp311-cp311-manylinux2014_aarch64.whl" \
  "${WORKSPACE_ROOT}/cann9_assets/sglang_router-0.3.2-cp38-abi3-manylinux_2_17_aarch64.manylinux2014_aarch64.whl" \
  "${WORKSPACE_ROOT}/wheelhouse/wandb-0.28.1-py3-none-manylinux_2_28_aarch64.whl" \
  "${WORKSPACE_ROOT}/cann9_assets/sgl_kernel_npu-2026.6.1-cp311-cp311-linux_aarch64.whl" \
  "${WORKSPACE_ROOT}/cann9_assets/attentions-0.2-cp311-cp311-linux_aarch64.whl"

python3 -m pip install --no-deps --no-build-isolation -e "${SLIME_SOURCE}"
python3 -m pip install --no-deps --no-build-isolation -e "${SGLANG_SOURCE}"

site_packages=$(python3 -c 'import sysconfig; print(sysconfig.get_paths()["purelib"])')
mkdir -p "${site_packages}/sgl_kernel_npu" "${site_packages}/attentions"
cp -a "${TORCH29_RUNTIME_OVERLAY}/sgl_kernel_npu/." "${site_packages}/sgl_kernel_npu/"
cp -a "${TORCH29_RUNTIME_OVERLAY}/attentions/." "${site_packages}/attentions/"

python3 - <<'PY'
import ray
import sglang
import sglang_router
import wandb
import torch
import torch_npu

device_count = torch.npu.device_count()
native_status = "deferred:no_visible_npu"
if device_count:
    import attentions
    import sgl_kernel_npu

    native_status = {
        "sgl_kernel_npu": getattr(sgl_kernel_npu, "__version__", "imported"),
        "attentions": getattr(attentions, "__version__", "imported"),
    }

print(
    {
        "ray": ray.__version__,
        "sglang": getattr(sglang, "__version__", "unknown"),
        "wandb": wandb.__version__,
        "visible_npu": device_count,
        "native_runtime": native_status,
    }
)
PY
