#!/usr/bin/env bash
set -euo pipefail

: "${WORK_ROOT:?Set WORK_ROOT to the persistent experiment directory}"
: "${MODEL_DIR:?Set MODEL_DIR to the local Qwen3.5-9B directory}"
: "${ALLOW_HAL_FULL_DEVICE_ACCESS:?Set ALLOW_HAL_FULL_DEVICE_ACCESS=1 only after explicit authorization}"

if [[ "${ALLOW_HAL_FULL_DEVICE_ACCESS}" != "1" ]]; then
  echo "Refusing full HAL device mapping without ALLOW_HAL_FULL_DEVICE_ACCESS=1" >&2
  exit 1
fi

CONTAINER_NAME="${CONTAINER_NAME:-slime-qwen35-rl-8x}"
IMAGE="${IMAGE:-quay.io/ascend/ms-swift@sha256:0116ad4e0b2b440b3ff7353f24fca741a3173b1e9fcea595c99d358347f47952}"
NPU_DEVICE_IDS="${NPU_DEVICE_IDS:-8,9,10,11,12,13,14,15}"
ALLOWED_NPU_DEVICE_IDS="${ALLOWED_NPU_DEVICE_IDS:-8,9,10,11,12,13,14,15}"
NETWORK_MODE="${NETWORK_MODE:-bridge}"
IPC_MODE="${IPC_MODE:-private}"

for path in "${WORK_ROOT}" "${MODEL_DIR}" /usr/local/Ascend/driver /usr/local/Ascend/add-ons; do
  if [[ ! -e "${path}" ]]; then
    echo "Required path does not exist: ${path}" >&2
    exit 1
  fi
done

if docker container inspect "${CONTAINER_NAME}" >/dev/null 2>&1; then
  echo "Container already exists: ${CONTAINER_NAME}" >&2
  exit 1
fi

device_args=(
  --device /dev/davinci_manager
  --device /dev/devmm_svm
  --device /dev/hisi_hdc
)
IFS=',' read -r -a requested_devices <<<"${NPU_DEVICE_IDS}"
if [[ ${#requested_devices[@]} -eq 0 ]]; then
  echo "NPU_DEVICE_IDS must contain at least one device" >&2
  exit 1
fi
declare -A seen_devices=()
for index in "${requested_devices[@]}"; do
  if [[ ! "${index}" =~ ^[0-9]+$ ]]; then
    echo "Invalid NPU device id: ${index}" >&2
    exit 1
  fi
  if [[ ",${ALLOWED_NPU_DEVICE_IDS}," != *",${index},"* ]]; then
    echo "NPU device ${index} is outside ALLOWED_NPU_DEVICE_IDS=${ALLOWED_NPU_DEVICE_IDS}" >&2
    exit 1
  fi
  if [[ -n "${seen_devices[${index}]:-}" ]]; then
    echo "Duplicate NPU device id: ${index}" >&2
    exit 1
  fi
  seen_devices[${index}]=1
  device="/dev/davinci${index}"
  if [[ ! -e "${device}" ]]; then
    echo "Required NPU device does not exist: ${device}" >&2
    exit 1
  fi
done

# The current Ascend 26.0.rc1 HAL opens and issues ioctls against the complete
# physical device sequence during initialization, so all nodes require rwm at
# the container boundary. This broader mapping is protected by the explicit
# gate above. Compute visibility remains restricted to NPU_DEVICE_IDS through
# ASCEND_RT_VISIBLE_DEVICES, and requested IDs are limited by the allow-list.
for index in $(seq 0 15); do
  device="/dev/davinci${index}"
  if [[ ! -e "${device}" ]]; then
    echo "Required NPU enumeration node does not exist: ${device}" >&2
    exit 1
  fi
  device_args+=(--device "${device}:${device}:rwm")
done

docker run -d \
  --name "${CONTAINER_NAME}" \
  --network "${NETWORK_MODE}" \
  --ipc "${IPC_MODE}" \
  --shm-size 128g \
  -e "ASCEND_RT_VISIBLE_DEVICES=${NPU_DEVICE_IDS}" \
  -e "PHYSICAL_NPU_DEVICE_IDS=${NPU_DEVICE_IDS}" \
  "${device_args[@]}" \
  -v /usr/local/Ascend/driver:/usr/local/Ascend/driver:ro \
  -v /usr/local/Ascend/add-ons:/usr/local/Ascend/add-ons:ro \
  -v /usr/local/sbin:/usr/local/sbin:ro \
  -v "${WORK_ROOT}:/workspace" \
  -v "${MODEL_DIR}:/models/Qwen3.5-9B:ro" \
  "${IMAGE}" \
  sleep infinity
