#!/usr/bin/env python3
"""Attach private verifier IDs to prompt-only splits and drop unsupported tasks."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any, Iterable


def iter_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open(encoding="utf-8") as handle:
        for line_number, raw_line in enumerate(handle, start=1):
            if not raw_line.strip():
                continue
            value = json.loads(raw_line)
            if not isinstance(value, dict):
                raise ValueError(f"{path}:{line_number}: expected a JSON object")
            yield value


def stable_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def verifier_key(environment: dict[str, Any]) -> str:
    return f"{environment.get('environment_id')}:{environment.get('task_id')}"


def filter_records(
    records: Iterable[dict[str, Any]], verifiers: dict[str, dict[str, Any]], split: str
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    kept: list[dict[str, Any]] = []
    rejected: list[dict[str, Any]] = []
    for input_line, record in enumerate(records, start=1):
        metadata = record.get("metadata")
        if not isinstance(metadata, dict) or not isinstance(metadata.get("environment"), dict):
            raise ValueError(f"{split}:{input_line}: missing metadata.environment")
        key = verifier_key(metadata["environment"])
        verifier = verifiers.get(key)
        if verifier is None:
            rejected.append({"split": split, "input_line": input_line, "verifier_id": key})
            continue
        metadata["verifier_id"] = verifier["verifier_id"]
        metadata["reward_contract"] = "private_sql_verifier_v1"
        rendered = stable_json(record)
        if "verification_sql" in rendered or '"gold"' in rendered:
            raise ValueError(f"{split}:{input_line}: private verifier content leaked into prompt record")
        kept.append(record)
    return kept, rejected


def write_jsonl(path: Path, records: list[dict[str, Any]]) -> str:
    digest = hashlib.sha256()
    with path.open("wb") as handle:
        for record in records:
            raw = (stable_json(record) + "\n").encode("utf-8")
            handle.write(raw)
            digest.update(raw)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("prompt_dir", type=Path)
    parser.add_argument("verifier_manifest", type=Path)
    parser.add_argument("output_dir", type=Path)
    args = parser.parse_args()

    verifiers = {
        str(row["verifier_id"]): row for row in iter_jsonl(args.verifier_manifest.resolve())
    }
    if not verifiers:
        raise RuntimeError("verifier manifest is empty")
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    summary: dict[str, Any] = {
        "contract": {
            "contains_gold": False,
            "contains_verification_sql": False,
            "verifier_lookup": "metadata.verifier_id",
            "reward_contract": "private_sql_verifier_v1",
        },
        "verifier_records": len(verifiers),
    }
    all_rejected: list[dict[str, Any]] = []
    for split in ("train", "eval"):
        source = args.prompt_dir.resolve() / f"{split}_prompts.jsonl"
        kept, rejected = filter_records(iter_jsonl(source), verifiers, split)
        output = output_dir / f"{split}_prompts.jsonl"
        summary[split] = {
            "source": str(source),
            "records": len(kept),
            "sha256": write_jsonl(output, kept),
        }
        all_rejected.extend(rejected)

    rejected_path = output_dir / "rejected_prompts.json"
    rejected_path.write_text(
        json.dumps(all_rejected, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    summary["rejected_records"] = len(all_rejected)
    summary["rejected_path"] = str(rejected_path)
    manifest = output_dir / "manifest.json"
    manifest.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
